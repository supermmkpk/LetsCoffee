package com.graduate2.project.domain;

public enum CafeEnum {
    STARBUCKS
}
