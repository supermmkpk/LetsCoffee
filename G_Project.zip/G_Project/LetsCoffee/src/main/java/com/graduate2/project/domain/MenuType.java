package com.graduate2.project.domain;

public enum MenuType {
    drink, food, product
}
